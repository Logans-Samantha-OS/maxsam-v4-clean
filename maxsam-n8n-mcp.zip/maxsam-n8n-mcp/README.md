# MaxSam N8N MCP Server v2.0.0

Enhanced MCP server for MaxSam V4 with N8N operations, property calculations, agreement automation, Telegram notifications, and agent memory logging.

## 🚀 Features

### N8N Operations (4 tools)
- `n8n_get_credentials` - List available N8N credentials
- `n8n_test_webhook` - Test webhook triggers
- `n8n_get_execution_data` - Get detailed execution results
- `n8n_duplicate_workflow` - Clone a workflow

### Property Calculations (3 tools)
- `calculate_offer_price` - ARV × 0.70 - repairs formula
- `calculate_buybox_price` - Suggest BuyBoxCartel listing range
- `get_leads_missing_arv` - Find leads that need Zillow scraping

### Agreement Automation (2 tools)
- `generate_agreement_data` - Prepare data for wholesale agreement
- `mark_agreement_sent` - Track agreement status

### Telegram Notifications (1 tool)
- `send_telegram_message` - Send notifications directly (for 8 AM summary)

### Agent Memory (2 tools)
- `log_agent_action` - Log what ALEX/ELEANOR/SAM did
- `get_agent_logs` - View agent activity

## 📦 Installation

```bash
cd maxsam-n8n-mcp
npm install
npm run build
```

## ⚙️ Configuration

Set these environment variables:

```bash
# N8N Configuration
export N8N_BASE_URL="https://skooki.app.n8n.cloud"
export N8N_API_KEY="your-n8n-api-key"

# Supabase Configuration
export SUPABASE_URL="your-supabase-url"
export SUPABASE_ANON_KEY="your-supabase-anon-key"

# Telegram Configuration
export TELEGRAM_BOT_TOKEN="your-telegram-bot-token"
export TELEGRAM_DEFAULT_CHAT_ID="your-chat-id"
```

## 🔧 Claude Desktop Configuration

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "maxsam-n8n": {
      "command": "node",
      "args": ["C:\\Users\\MrTin\\Downloads\\MaxSam-V4\\maxsam-n8n-mcp\\dist\\index.js"],
      "env": {
        "N8N_BASE_URL": "https://skooki.app.n8n.cloud",
        "N8N_API_KEY": "your-api-key",
        "SUPABASE_URL": "your-supabase-url",
        "SUPABASE_ANON_KEY": "your-anon-key",
        "TELEGRAM_BOT_TOKEN": "your-bot-token",
        "TELEGRAM_DEFAULT_CHAT_ID": "your-chat-id"
      }
    }
  }
}
```

## 📋 Tool Reference

### N8N Tools

#### n8n_get_credentials
```typescript
// No parameters required
// Returns: Array of credentials with id, name, type
```

#### n8n_test_webhook
```typescript
{
  webhookPath: "/webhook/skip-trace",  // or full URL
  payload: { leadId: "123" }           // optional
}
```

#### n8n_get_execution_data
```typescript
{
  executionId: "12345"
}
```

#### n8n_duplicate_workflow
```typescript
{
  workflowId: "abc123",
  newName: "My Copy"  // optional
}
```

### Property Tools

#### calculate_offer_price
```typescript
{
  arv: 350000,      // After Repair Value
  repairs: 25000    // Estimated repairs
}
// Returns: maxOffer = (350000 × 0.70) - 25000 = $220,000
```

#### calculate_buybox_price
```typescript
{
  purchasePrice: 200000,
  arv: 350000,
  wholesaleFeePercent: 0.10  // optional, default 10%
}
// Returns: recommendedListMin, recommendedListMax, expectedProfit
```

#### get_leads_missing_arv
```typescript
{
  limit: 50  // optional, default 50
}
```

### Agreement Tools

#### generate_agreement_data
```typescript
{
  leadId: "lead_123",
  purchasePrice: 200000,
  earnestMoney: 5000,
  closingDays: 30,           // optional
  additionalTerms: "..."     // optional
}
```

#### mark_agreement_sent
```typescript
{
  leadId: "lead_123",
  agreementId: "docusign_envelope_xyz",
  sentVia: "docusign"  // "email" | "sms" | "docusign"
}
```

### Telegram

#### send_telegram_message
```typescript
{
  text: "🌅 Good morning! Here's your 8 AM summary...",
  chatId: "123456789",    // optional if default set
  parseMode: "HTML",      // optional
  silent: false           // optional
}
```

### Agent Memory

#### log_agent_action
```typescript
{
  agentName: "ALEX",
  actionType: "skip_trace",
  actionDetails: { leadId: "123", found: true, phone: "555-1234" },
  leadId: "123",          // optional
  success: true,
  errorMessage: null,     // optional
  duration: 3500          // ms, optional
}
```

#### get_agent_logs
```typescript
{
  agentName: "SAM",       // optional filter
  actionType: "sms_sent", // optional filter
  leadId: "123",          // optional filter
  success: true,          // optional filter
  startDate: "2025-01-01T00:00:00Z",  // optional
  endDate: "2025-01-22T23:59:59Z",    // optional
  limit: 100              // optional, default 50
}
```

## 🗄️ Required Database Tables

Ensure these tables exist in Supabase:

### agent_memories
```sql
CREATE TABLE agent_memories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_name TEXT NOT NULL CHECK (agent_name IN ('ALEX', 'ELEANOR', 'SAM')),
  action_type TEXT NOT NULL,
  action_details JSONB,
  lead_id TEXT,
  success BOOLEAN NOT NULL,
  error_message TEXT,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  duration INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_agent_memories_agent ON agent_memories(agent_name);
CREATE INDEX idx_agent_memories_timestamp ON agent_memories(timestamp DESC);
CREATE INDEX idx_agent_memories_lead ON agent_memories(lead_id);
```

### leads (ensure these columns exist)
```sql
-- Add these columns if not present
ALTER TABLE leads ADD COLUMN IF NOT EXISTS arv NUMERIC;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS agreement_id TEXT;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS agreement_status TEXT;
ALTER TABLE leads ADD COLUMN IF NOT EXISTS agreement_sent_at TIMESTAMPTZ;
```

## 🔗 N8N Webhook Endpoints

The server is pre-configured with these webhook paths:

- `/webhook/skip-trace` - ALEX skip tracing
- `/webhook/sam-initial-outreach` - SAM SMS outreach
- `/webhook/eleanor-score` - ELEANOR lead scoring
- `/webhook/send-agreement` - Agreement sending
- `/webhook/deal-blast` - Deal blast notifications

## 📝 License

MIT - MaxSam Recovery Services
