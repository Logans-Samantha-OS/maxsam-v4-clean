// MaxSam N8N MCP Server Types

// ============ N8N Types ============
export interface N8NCredential {
  id: string;
  name: string;
  type: string;
  createdAt: string;
  updatedAt: string;
}

export interface N8NWorkflow {
  id: string;
  name: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
  nodes?: N8NNode[];
  connections?: Record<string, unknown>;
}

export interface N8NNode {
  name: string;
  type: string;
  position: [number, number];
  parameters?: Record<string, unknown>;
}

export interface N8NExecution {
  id: string;
  finished: boolean;
  mode: string;
  startedAt: string;
  stoppedAt?: string;
  workflowId: string;
  status: 'success' | 'error' | 'waiting' | 'running';
  data?: {
    resultData?: {
      runData?: Record<string, unknown>;
    };
  };
}

export interface WebhookTestResult {
  success: boolean;
  statusCode?: number;
  response?: unknown;
  error?: string;
  duration?: number;
}

// ============ Property/Zillow Types ============
export interface OfferCalculation {
  arv: number;
  repairs: number;
  maxOffer: number;
  formula: string;
  profitMargin: number;
}

export interface BuyBoxCalculation {
  purchasePrice: number;
  arv: number;
  recommendedListMin: number;
  recommendedListMax: number;
  wholesaleFee: number;
  expectedProfit: number;
}

export interface LeadMissingARV {
  id: string;
  name: string;
  address: string;
  city?: string;
  state?: string;
  zip?: string;
  excessFundsAmount?: number;
  createdAt: string;
}

// ============ Agreement Types ============
export interface AgreementData {
  leadId: string;
  sellerName: string;
  sellerAddress: string;
  propertyAddress: string;
  purchasePrice: number;
  earnestMoney: number;
  closingDate: string;
  contingencies?: string[];
  additionalTerms?: string;
  generatedAt: string;
}

export interface AgreementStatus {
  leadId: string;
  agreementId: string;
  status: 'draft' | 'sent' | 'viewed' | 'signed' | 'expired';
  sentAt?: string;
  viewedAt?: string;
  signedAt?: string;
}

// ============ Telegram Types ============
export interface TelegramMessage {
  chatId: string;
  text: string;
  parseMode?: 'HTML' | 'Markdown' | 'MarkdownV2';
  disableNotification?: boolean;
}

export interface TelegramResponse {
  ok: boolean;
  messageId?: number;
  error?: string;
}

// ============ Agent Memory Types ============
export interface AgentAction {
  id?: string;
  agentName: 'ALEX' | 'ELEANOR' | 'SAM';
  actionType: string;
  actionDetails: Record<string, unknown>;
  leadId?: string;
  success: boolean;
  errorMessage?: string;
  timestamp: string;
  duration?: number;
}

export interface AgentLogFilter {
  agentName?: 'ALEX' | 'ELEANOR' | 'SAM';
  actionType?: string;
  leadId?: string;
  success?: boolean;
  startDate?: string;
  endDate?: string;
  limit?: number;
}

// ============ Config Types ============
export interface N8NConfig {
  baseUrl: string;
  apiKey: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
}

export interface TelegramConfig {
  botToken: string;
  defaultChatId: string;
}

export interface MaxSamConfig {
  n8n: N8NConfig;
  supabase: SupabaseConfig;
  telegram: TelegramConfig;
}
