import {
  ARV_MULTIPLIER,
  DEFAULT_WHOLESALE_FEE_PERCENT,
  BUYBOX_LIST_MIN_MULTIPLIER,
  BUYBOX_LIST_MAX_MULTIPLIER,
} from '../constants.js';
import type { OfferCalculation, BuyBoxCalculation } from '../types.js';

/**
 * Calculate maximum offer price using ARV × 0.70 - repairs formula
 * This is the standard wholesale formula for MaxSam
 */
export function calculateOfferPrice(arv: number, repairs: number): OfferCalculation {
  const maxOffer = (arv * ARV_MULTIPLIER) - repairs;
  const profitMargin = arv - maxOffer - repairs;
  
  return {
    arv,
    repairs,
    maxOffer: Math.round(maxOffer * 100) / 100,
    formula: `(${formatCurrency(arv)} × ${ARV_MULTIPLIER}) - ${formatCurrency(repairs)} = ${formatCurrency(maxOffer)}`,
    profitMargin: Math.round(profitMargin * 100) / 100,
  };
}

/**
 * Calculate BuyBoxCartel listing price range
 * For deals being sold to other investors
 */
export function calculateBuyBoxPrice(
  purchasePrice: number,
  arv: number,
  wholesaleFeePercent: number = DEFAULT_WHOLESALE_FEE_PERCENT
): BuyBoxCalculation {
  const wholesaleFee = purchasePrice * wholesaleFeePercent;
  const recommendedListMin = arv * BUYBOX_LIST_MIN_MULTIPLIER;
  const recommendedListMax = arv * BUYBOX_LIST_MAX_MULTIPLIER;
  
  // Expected profit = what we list at minus what we paid minus our fee
  const avgListPrice = (recommendedListMin + recommendedListMax) / 2;
  const expectedProfit = avgListPrice - purchasePrice;
  
  return {
    purchasePrice,
    arv,
    recommendedListMin: Math.round(recommendedListMin),
    recommendedListMax: Math.round(recommendedListMax),
    wholesaleFee: Math.round(wholesaleFee * 100) / 100,
    expectedProfit: Math.round(expectedProfit),
  };
}

/**
 * Format number as currency string
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Validate ARV value
 */
export function validateARV(arv: number): { valid: boolean; error?: string } {
  if (arv <= 0) {
    return { valid: false, error: 'ARV must be greater than 0' };
  }
  if (arv > 10000000) {
    return { valid: false, error: 'ARV seems unrealistically high (>$10M). Please verify.' };
  }
  return { valid: true };
}

/**
 * Validate repairs estimate
 */
export function validateRepairs(repairs: number, arv: number): { valid: boolean; error?: string } {
  if (repairs < 0) {
    return { valid: false, error: 'Repairs cannot be negative' };
  }
  if (repairs > arv * 0.5) {
    return { valid: false, error: 'Repairs exceed 50% of ARV. This deal may not be viable.' };
  }
  return { valid: true };
}
