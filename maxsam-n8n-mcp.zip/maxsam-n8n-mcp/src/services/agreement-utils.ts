import type { AgreementData, AgreementStatus } from '../types.js';
import { supabaseClient } from './api-clients.js';
import { formatCurrency } from './property-calculations.js';

/**
 * Generate agreement data from a lead for wholesale contract
 */
export async function generateAgreementData(
  leadId: string,
  purchasePrice: number,
  earnestMoney: number,
  closingDays: number = 30,
  additionalTerms?: string
): Promise<AgreementData> {
  // Fetch lead data
  const lead = await supabaseClient.getLead(leadId);
  
  if (!lead) {
    throw new Error(`Lead ${leadId} not found`);
  }
  
  // Calculate closing date
  const closingDate = new Date();
  closingDate.setDate(closingDate.getDate() + closingDays);
  
  // Build seller name from lead data
  const sellerName = buildSellerName(lead);
  
  // Build addresses
  const sellerAddress = buildFullAddress(
    lead.mailing_address as string || lead.address as string,
    lead.mailing_city as string || lead.city as string,
    lead.mailing_state as string || lead.state as string,
    lead.mailing_zip as string || lead.zip as string
  );
  
  const propertyAddress = buildFullAddress(
    lead.address as string,
    lead.city as string,
    lead.state as string,
    lead.zip as string
  );
  
  // Standard contingencies for wholesale deals
  const contingencies = [
    'Inspection contingency - 10 business days',
    'Title contingency - Clear and marketable title required',
    'Assignment clause - This contract may be assigned to a third party',
    'Financing contingency waived - Cash purchase',
  ];
  
  return {
    leadId,
    sellerName,
    sellerAddress,
    propertyAddress,
    purchasePrice,
    earnestMoney,
    closingDate: closingDate.toISOString().split('T')[0],
    contingencies,
    additionalTerms,
    generatedAt: new Date().toISOString(),
  };
}

/**
 * Mark an agreement as sent and track status
 */
export async function markAgreementSent(
  leadId: string,
  agreementId: string,
  sentVia: 'email' | 'sms' | 'docusign' = 'email'
): Promise<AgreementStatus> {
  const sentAt = new Date().toISOString();
  
  // Update lead in database
  await supabaseClient.updateAgreementStatus(leadId, agreementId, 'sent', sentAt);
  
  return {
    leadId,
    agreementId,
    status: 'sent',
    sentAt,
  };
}

/**
 * Build seller name from lead data
 */
function buildSellerName(lead: Record<string, unknown>): string {
  const firstName = lead.first_name as string || lead.name as string || '';
  const lastName = lead.last_name as string || '';
  
  if (lastName) {
    return `${firstName} ${lastName}`.trim();
  }
  return firstName.trim() || 'Property Owner';
}

/**
 * Build full address string
 */
function buildFullAddress(
  street?: string,
  city?: string,
  state?: string,
  zip?: string
): string {
  const parts: string[] = [];
  
  if (street) parts.push(street);
  
  const cityStateZip: string[] = [];
  if (city) cityStateZip.push(city);
  if (state) cityStateZip.push(state);
  if (zip) cityStateZip.push(zip);
  
  if (cityStateZip.length > 0) {
    parts.push(cityStateZip.join(', '));
  }
  
  return parts.join('\n');
}

/**
 * Format agreement data as readable summary
 */
export function formatAgreementSummary(data: AgreementData): string {
  return `
📋 WHOLESALE AGREEMENT SUMMARY
================================
Lead ID: ${data.leadId}
Generated: ${new Date(data.generatedAt).toLocaleString()}

🏠 PROPERTY DETAILS
Address: ${data.propertyAddress}

👤 SELLER INFORMATION
Name: ${data.sellerName}
Address: ${data.sellerAddress}

💰 DEAL TERMS
Purchase Price: ${formatCurrency(data.purchasePrice)}
Earnest Money: ${formatCurrency(data.earnestMoney)}
Closing Date: ${data.closingDate}

📝 CONTINGENCIES
${data.contingencies?.map(c => `• ${c}`).join('\n') || 'None'}

${data.additionalTerms ? `📎 ADDITIONAL TERMS\n${data.additionalTerms}` : ''}
`.trim();
}
