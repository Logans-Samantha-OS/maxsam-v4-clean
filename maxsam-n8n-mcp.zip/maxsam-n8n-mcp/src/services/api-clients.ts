import axios, { AxiosInstance, AxiosError } from 'axios';
import {
  N8N_BASE_URL,
  N8N_API_KEY,
  SUPABASE_URL,
  SUPABASE_ANON_KEY,
  TELEGRAM_BOT_TOKEN,
  API_TIMEOUT_MS,
  WEBHOOK_TIMEOUT_MS,
} from './constants.js';
import type {
  N8NCredential,
  N8NWorkflow,
  N8NExecution,
  WebhookTestResult,
  AgentAction,
  AgentLogFilter,
  LeadMissingARV,
  TelegramResponse,
} from './types.js';

// ============ N8N API Client ============
class N8NClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: `${N8N_BASE_URL}/api/v1`,
      timeout: API_TIMEOUT_MS,
      headers: {
        'X-N8N-API-KEY': N8N_API_KEY,
        'Content-Type': 'application/json',
      },
    });
  }

  async getCredentials(): Promise<N8NCredential[]> {
    try {
      const response = await this.client.get('/credentials');
      return response.data.data || [];
    } catch (error) {
      throw this.handleError(error, 'Failed to fetch credentials');
    }
  }

  async testWebhook(webhookUrl: string, payload?: Record<string, unknown>): Promise<WebhookTestResult> {
    const startTime = Date.now();
    try {
      const fullUrl = webhookUrl.startsWith('http') ? webhookUrl : `${N8N_BASE_URL}${webhookUrl}`;
      const response = await axios.post(fullUrl, payload || {}, {
        timeout: WEBHOOK_TIMEOUT_MS,
        headers: { 'Content-Type': 'application/json' },
      });
      return {
        success: true,
        statusCode: response.status,
        response: response.data,
        duration: Date.now() - startTime,
      };
    } catch (error) {
      const axiosError = error as AxiosError;
      return {
        success: false,
        statusCode: axiosError.response?.status,
        error: axiosError.message,
        duration: Date.now() - startTime,
      };
    }
  }

  async getExecutionData(executionId: string): Promise<N8NExecution> {
    try {
      const response = await this.client.get(`/executions/${executionId}`);
      return response.data;
    } catch (error) {
      throw this.handleError(error, `Failed to fetch execution ${executionId}`);
    }
  }

  async duplicateWorkflow(workflowId: string, newName?: string): Promise<N8NWorkflow> {
    try {
      // First get the workflow
      const getResponse = await this.client.get(`/workflows/${workflowId}`);
      const workflow = getResponse.data;
      
      // Create a copy with new name
      const duplicateData = {
        ...workflow,
        id: undefined,
        name: newName || `${workflow.name} (Copy)`,
        active: false,
      };
      
      const response = await this.client.post('/workflows', duplicateData);
      return response.data;
    } catch (error) {
      throw this.handleError(error, `Failed to duplicate workflow ${workflowId}`);
    }
  }

  async listWorkflows(): Promise<N8NWorkflow[]> {
    try {
      const response = await this.client.get('/workflows');
      return response.data.data || [];
    } catch (error) {
      throw this.handleError(error, 'Failed to list workflows');
    }
  }

  async getWorkflow(workflowId: string): Promise<N8NWorkflow> {
    try {
      const response = await this.client.get(`/workflows/${workflowId}`);
      return response.data;
    } catch (error) {
      throw this.handleError(error, `Failed to fetch workflow ${workflowId}`);
    }
  }

  private handleError(error: unknown, context: string): Error {
    if (axios.isAxiosError(error)) {
      const status = error.response?.status;
      const message = error.response?.data?.message || error.message;
      return new Error(`${context}: [${status}] ${message}`);
    }
    return new Error(`${context}: ${String(error)}`);
  }
}

// ============ Supabase Client ============
class SupabaseClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: `${SUPABASE_URL}/rest/v1`,
      timeout: API_TIMEOUT_MS,
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
      },
    });
  }

  async logAgentAction(action: AgentAction): Promise<AgentAction> {
    try {
      const response = await this.client.post('/agent_memories', {
        agent_name: action.agentName,
        action_type: action.actionType,
        action_details: action.actionDetails,
        lead_id: action.leadId,
        success: action.success,
        error_message: action.errorMessage,
        timestamp: action.timestamp || new Date().toISOString(),
        duration: action.duration,
      });
      return response.data[0];
    } catch (error) {
      throw this.handleError(error, 'Failed to log agent action');
    }
  }

  async getAgentLogs(filter: AgentLogFilter): Promise<AgentAction[]> {
    try {
      let query = '/agent_memories?select=*';
      
      if (filter.agentName) {
        query += `&agent_name=eq.${filter.agentName}`;
      }
      if (filter.actionType) {
        query += `&action_type=eq.${filter.actionType}`;
      }
      if (filter.leadId) {
        query += `&lead_id=eq.${filter.leadId}`;
      }
      if (filter.success !== undefined) {
        query += `&success=eq.${filter.success}`;
      }
      if (filter.startDate) {
        query += `&timestamp=gte.${filter.startDate}`;
      }
      if (filter.endDate) {
        query += `&timestamp=lte.${filter.endDate}`;
      }
      
      query += `&order=timestamp.desc&limit=${filter.limit || 50}`;
      
      const response = await this.client.get(query);
      return response.data;
    } catch (error) {
      throw this.handleError(error, 'Failed to fetch agent logs');
    }
  }

  async getLeadsMissingARV(limit: number = 50): Promise<LeadMissingARV[]> {
    try {
      const response = await this.client.get(
        `/leads?select=id,name,address,city,state,zip,excess_funds_amount,created_at&arv=is.null&order=created_at.desc&limit=${limit}`
      );
      return response.data.map((lead: Record<string, unknown>) => ({
        id: lead.id as string,
        name: lead.name as string,
        address: lead.address as string,
        city: lead.city as string | undefined,
        state: lead.state as string | undefined,
        zip: lead.zip as string | undefined,
        excessFundsAmount: lead.excess_funds_amount as number | undefined,
        createdAt: lead.created_at as string,
      }));
    } catch (error) {
      throw this.handleError(error, 'Failed to fetch leads missing ARV');
    }
  }

  async updateAgreementStatus(
    leadId: string,
    agreementId: string,
    status: string,
    sentAt?: string
  ): Promise<void> {
    try {
      await this.client.patch(
        `/leads?id=eq.${leadId}`,
        {
          agreement_id: agreementId,
          agreement_status: status,
          agreement_sent_at: sentAt || new Date().toISOString(),
        }
      );
    } catch (error) {
      throw this.handleError(error, 'Failed to update agreement status');
    }
  }

  async getLead(leadId: string): Promise<Record<string, unknown> | null> {
    try {
      const response = await this.client.get(`/leads?id=eq.${leadId}&select=*`);
      return response.data[0] || null;
    } catch (error) {
      throw this.handleError(error, `Failed to fetch lead ${leadId}`);
    }
  }

  private handleError(error: unknown, context: string): Error {
    if (axios.isAxiosError(error)) {
      const status = error.response?.status;
      const message = error.response?.data?.message || error.message;
      return new Error(`${context}: [${status}] ${message}`);
    }
    return new Error(`${context}: ${String(error)}`);
  }
}

// ============ Telegram Client ============
class TelegramClient {
  private baseUrl: string;

  constructor() {
    this.baseUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;
  }

  async sendMessage(
    chatId: string,
    text: string,
    parseMode?: 'HTML' | 'Markdown' | 'MarkdownV2',
    disableNotification?: boolean
  ): Promise<TelegramResponse> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/sendMessage`,
        {
          chat_id: chatId,
          text,
          parse_mode: parseMode,
          disable_notification: disableNotification,
        },
        { timeout: API_TIMEOUT_MS }
      );
      
      return {
        ok: response.data.ok,
        messageId: response.data.result?.message_id,
      };
    } catch (error) {
      if (axios.isAxiosError(error)) {
        return {
          ok: false,
          error: error.response?.data?.description || error.message,
        };
      }
      return {
        ok: false,
        error: String(error),
      };
    }
  }
}

// Export singleton instances
export const n8nClient = new N8NClient();
export const supabaseClient = new SupabaseClient();
export const telegramClient = new TelegramClient();
