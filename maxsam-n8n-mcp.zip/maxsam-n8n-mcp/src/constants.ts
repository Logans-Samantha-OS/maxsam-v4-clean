// MaxSam N8N MCP Server Constants

// N8N Configuration
export const N8N_BASE_URL = process.env.N8N_BASE_URL || 'https://skooki.app.n8n.cloud';
export const N8N_API_KEY = process.env.N8N_API_KEY || '';

// Supabase Configuration
export const SUPABASE_URL = process.env.SUPABASE_URL || '';
export const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || '';

// Telegram Configuration
export const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
export const TELEGRAM_DEFAULT_CHAT_ID = process.env.TELEGRAM_DEFAULT_CHAT_ID || '';

// Webhook Endpoints
export const WEBHOOK_ENDPOINTS = {
  skipTrace: '/webhook/skip-trace',
  samInitialOutreach: '/webhook/sam-initial-outreach',
  eleanorScore: '/webhook/eleanor-score',
  sendAgreement: '/webhook/send-agreement',
  dealBlast: '/webhook/deal-blast',
} as const;

// Property Calculation Constants
export const ARV_MULTIPLIER = 0.70;  // 70% of ARV for max offer
export const DEFAULT_WHOLESALE_FEE_PERCENT = 0.10;  // 10% wholesale fee
export const BUYBOX_LIST_MIN_MULTIPLIER = 0.75;  // 75% of ARV for min list
export const BUYBOX_LIST_MAX_MULTIPLIER = 0.82;  // 82% of ARV for max list

// Agent Names
export const AGENT_NAMES = ['ALEX', 'ELEANOR', 'SAM'] as const;

// Character limit for responses
export const CHARACTER_LIMIT = 50000;

// API Timeouts
export const API_TIMEOUT_MS = 30000;
export const WEBHOOK_TIMEOUT_MS = 10000;
