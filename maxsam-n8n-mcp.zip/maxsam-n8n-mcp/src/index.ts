import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

import { n8nClient, supabaseClient, telegramClient } from "./services/api-clients.js";
import { calculateOfferPrice, calculateBuyBoxPrice, validateARV, validateRepairs, formatCurrency } from "./services/property-calculations.js";
import { generateAgreementData, markAgreementSent, formatAgreementSummary } from "./services/agreement-utils.js";
import { TELEGRAM_DEFAULT_CHAT_ID, WEBHOOK_ENDPOINTS, AGENT_NAMES } from "./constants.js";

// Initialize MCP Server
const server = new McpServer({
  name: "maxsam-n8n-mcp-server",
  version: "2.0.0",
});

// ============================================================
// N8N TOOLS
// ============================================================

// 1. n8n_get_credentials - List available N8N credentials
server.registerTool(
  "n8n_get_credentials",
  {
    title: "List N8N Credentials",
    description: `List all available credentials configured in N8N.

Returns credentials with their IDs, names, types, and timestamps.
Useful for verifying integration setup and debugging workflow issues.

Returns: Array of credentials with id, name, type, createdAt, updatedAt`,
    inputSchema: z.object({}).strict(),
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async () => {
    try {
      const credentials = await n8nClient.getCredentials();
      
      const summary = credentials.map(cred => 
        `• ${cred.name} (${cred.type}) - ID: ${cred.id}`
      ).join('\n');
      
      return {
        content: [{
          type: "text",
          text: `Found ${credentials.length} credentials:\n\n${summary}`,
        }],
        structuredContent: { credentials },
      };
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error fetching credentials: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// 2. n8n_test_webhook - Test a webhook trigger
server.registerTool(
  "n8n_test_webhook",
  {
    title: "Test N8N Webhook",
    description: `Test an N8N webhook endpoint with optional payload.

Sends a POST request to the specified webhook and returns the response.
Use this to verify webhook configurations are working properly.

Args:
  - webhookPath: The webhook path (e.g., '/webhook/skip-trace') or full URL
  - payload: Optional JSON payload to send with the request

Returns: Success status, HTTP status code, response data, and duration`,
    inputSchema: z.object({
      webhookPath: z.string()
        .describe("Webhook path (e.g., '/webhook/skip-trace') or full URL"),
      payload: z.record(z.unknown())
        .optional()
        .describe("Optional JSON payload to send"),
    }).strict(),
    annotations: {
      readOnlyHint: false,
      destructiveHint: false,
      idempotentHint: false,
      openWorldHint: true,
    },
  },
  async ({ webhookPath, payload }) => {
    try {
      const result = await n8nClient.testWebhook(webhookPath, payload);
      
      const status = result.success ? '✅ SUCCESS' : '❌ FAILED';
      const text = `${status}
HTTP Status: ${result.statusCode || 'N/A'}
Duration: ${result.duration}ms
${result.error ? `Error: ${result.error}` : ''}
${result.response ? `Response: ${JSON.stringify(result.response, null, 2)}` : ''}`;
      
      return {
        content: [{ type: "text", text }],
        structuredContent: result,
      };
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error testing webhook: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// 3. n8n_get_execution_data - Get detailed execution results
server.registerTool(
  "n8n_get_execution_data",
  {
    title: "Get N8N Execution Data",
    description: `Get detailed results from a specific N8N workflow execution.

Fetches the complete execution data including status, timing, and output data.
Use this to debug workflow runs or retrieve processed results.

Args:
  - executionId: The N8N execution ID

Returns: Execution details including status, timing, and run data`,
    inputSchema: z.object({
      executionId: z.string()
        .describe("The N8N execution ID to fetch"),
    }).strict(),
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async ({ executionId }) => {
    try {
      const execution = await n8nClient.getExecutionData(executionId);
      
      const statusEmoji = execution.status === 'success' ? '✅' : 
                          execution.status === 'error' ? '❌' : 
                          execution.status === 'running' ? '🔄' : '⏳';
      
      const text = `${statusEmoji} Execution ${executionId}
Status: ${execution.status}
Started: ${execution.startedAt}
${execution.stoppedAt ? `Stopped: ${execution.stoppedAt}` : 'Still running...'}
Workflow ID: ${execution.workflowId}`;
      
      return {
        content: [{ type: "text", text }],
        structuredContent: execution,
      };
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error fetching execution: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// 4. n8n_duplicate_workflow - Clone a workflow
server.registerTool(
  "n8n_duplicate_workflow",
  {
    title: "Duplicate N8N Workflow",
    description: `Clone an existing N8N workflow to create a copy.

Creates a duplicate of the specified workflow with an optional new name.
The new workflow will be inactive by default.

Args:
  - workflowId: The ID of the workflow to duplicate
  - newName: Optional name for the new workflow (defaults to "Original Name (Copy)")

Returns: The newly created workflow details`,
    inputSchema: z.object({
      workflowId: z.string()
        .describe("The ID of the workflow to duplicate"),
      newName: z.string()
        .optional()
        .describe("Optional name for the duplicated workflow"),
    }).strict(),
    annotations: {
      readOnlyHint: false,
      destructiveHint: false,
      idempotentHint: false,
      openWorldHint: false,
    },
  },
  async ({ workflowId, newName }) => {
    try {
      const newWorkflow = await n8nClient.duplicateWorkflow(workflowId, newName);
      
      return {
        content: [{
          type: "text",
          text: `✅ Workflow duplicated successfully!
New Workflow ID: ${newWorkflow.id}
Name: ${newWorkflow.name}
Active: ${newWorkflow.active}`,
        }],
        structuredContent: newWorkflow,
      };
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error duplicating workflow: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// ============================================================
// ZILLOW/PROPERTY CALCULATION TOOLS
// ============================================================

// 5. calculate_offer_price - ARV × 0.70 - repairs formula
server.registerTool(
  "calculate_offer_price",
  {
    title: "Calculate Offer Price",
    description: `Calculate maximum offer price using the wholesale formula: ARV × 0.70 - repairs.

This is the standard MaxSam formula for determining the highest price to offer
on a wholesale deal while maintaining profit margins.

Args:
  - arv: After Repair Value of the property
  - repairs: Estimated repair costs

Returns: Maximum offer price, formula breakdown, and profit margin`,
    inputSchema: z.object({
      arv: z.number()
        .positive("ARV must be positive")
        .describe("After Repair Value of the property"),
      repairs: z.number()
        .min(0, "Repairs cannot be negative")
        .describe("Estimated repair costs"),
    }).strict(),
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async ({ arv, repairs }) => {
    // Validate inputs
    const arvValidation = validateARV(arv);
    if (!arvValidation.valid) {
      return {
        content: [{ type: "text", text: `❌ Error: ${arvValidation.error}` }],
        isError: true,
      };
    }
    
    const repairsValidation = validateRepairs(repairs, arv);
    if (!repairsValidation.valid) {
      return {
        content: [{ type: "text", text: `⚠️ Warning: ${repairsValidation.error}` }],
      };
    }
    
    const result = calculateOfferPrice(arv, repairs);
    
    const text = `💰 OFFER CALCULATION
━━━━━━━━━━━━━━━━━━━━━
ARV: ${formatCurrency(arv)}
Repairs: ${formatCurrency(repairs)}

Formula: ${result.formula}

📊 RESULTS
Max Offer: ${formatCurrency(result.maxOffer)}
Profit Margin: ${formatCurrency(result.profitMargin)}`;
    
    return {
      content: [{ type: "text", text }],
      structuredContent: result,
    };
  }
);

// 6. calculate_buybox_price - BuyBoxCartel listing range
server.registerTool(
  "calculate_buybox_price",
  {
    title: "Calculate BuyBox Price",
    description: `Calculate recommended listing price range for BuyBoxCartel.

Determines the optimal price range to list a wholesale deal to other investors.
Uses 75-82% of ARV as the standard listing range.

Args:
  - purchasePrice: What you're paying for the property
  - arv: After Repair Value of the property
  - wholesaleFeePercent: Your wholesale fee percentage (default: 10%)

Returns: Recommended min/max listing prices, wholesale fee, and expected profit`,
    inputSchema: z.object({
      purchasePrice: z.number()
        .positive("Purchase price must be positive")
        .describe("What you're paying for the property"),
      arv: z.number()
        .positive("ARV must be positive")
        .describe("After Repair Value of the property"),
      wholesaleFeePercent: z.number()
        .min(0)
        .max(0.5)
        .optional()
        .default(0.10)
        .describe("Your wholesale fee percentage (default: 0.10 for 10%)"),
    }).strict(),
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async ({ purchasePrice, arv, wholesaleFeePercent }) => {
    const result = calculateBuyBoxPrice(purchasePrice, arv, wholesaleFeePercent);
    
    const text = `📊 BUYBOX LISTING ANALYSIS
━━━━━━━━━━━━━━━━━━━━━━━━━━
Purchase Price: ${formatCurrency(purchasePrice)}
ARV: ${formatCurrency(arv)}

📋 RECOMMENDED LISTING RANGE
Min: ${formatCurrency(result.recommendedListMin)} (75% of ARV)
Max: ${formatCurrency(result.recommendedListMax)} (82% of ARV)

💵 PROFIT BREAKDOWN
Wholesale Fee: ${formatCurrency(result.wholesaleFee)}
Expected Profit: ${formatCurrency(result.expectedProfit)}`;
    
    return {
      content: [{ type: "text", text }],
      structuredContent: result,
    };
  }
);

// 7. get_leads_missing_arv - Find leads needing Zillow scraping
server.registerTool(
  "get_leads_missing_arv",
  {
    title: "Get Leads Missing ARV",
    description: `Find leads in the database that don't have ARV values yet.

These leads need Zillow scraping to get property valuations.
Returns leads ordered by creation date (newest first).

Args:
  - limit: Maximum number of leads to return (default: 50)

Returns: List of leads with addresses but no ARV`,
    inputSchema: z.object({
      limit: z.number()
        .int()
        .min(1)
        .max(500)
        .optional()
        .default(50)
        .describe("Maximum leads to return (default: 50)"),
    }).strict(),
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async ({ limit }) => {
    try {
      const leads = await supabaseClient.getLeadsMissingARV(limit);
      
      if (leads.length === 0) {
        return {
          content: [{ type: "text", text: "✅ All leads have ARV values! No scraping needed." }],
          structuredContent: { leads: [], count: 0 },
        };
      }
      
      const summary = leads.slice(0, 10).map(lead => 
        `• ${lead.name || 'Unknown'} - ${lead.address}, ${lead.city || ''} ${lead.state || ''}`
      ).join('\n');
      
      const text = `🔍 Found ${leads.length} leads missing ARV values

Top 10 leads needing Zillow scraping:
${summary}
${leads.length > 10 ? `\n... and ${leads.length - 10} more` : ''}`;
      
      return {
        content: [{ type: "text", text }],
        structuredContent: { leads, count: leads.length },
      };
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error fetching leads: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// ============================================================
// AGREEMENT AUTOMATION TOOLS
// ============================================================

// 8. generate_agreement_data - Prepare data for wholesale agreement
server.registerTool(
  "generate_agreement_data",
  {
    title: "Generate Agreement Data",
    description: `Generate all data needed for a wholesale agreement from a lead.

Fetches lead data and compiles it into a structured format ready for
document generation or e-signature platforms like DocuSign.

Args:
  - leadId: The lead ID to generate agreement for
  - purchasePrice: The agreed purchase price
  - earnestMoney: Earnest money deposit amount
  - closingDays: Days until closing (default: 30)
  - additionalTerms: Optional additional contract terms

Returns: Complete agreement data with seller info, property details, and terms`,
    inputSchema: z.object({
      leadId: z.string()
        .describe("The lead ID to generate agreement for"),
      purchasePrice: z.number()
        .positive()
        .describe("The agreed purchase price"),
      earnestMoney: z.number()
        .min(0)
        .describe("Earnest money deposit amount"),
      closingDays: z.number()
        .int()
        .min(1)
        .max(180)
        .optional()
        .default(30)
        .describe("Days until closing (default: 30)"),
      additionalTerms: z.string()
        .optional()
        .describe("Optional additional contract terms"),
    }).strict(),
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async ({ leadId, purchasePrice, earnestMoney, closingDays, additionalTerms }) => {
    try {
      const agreementData = await generateAgreementData(
        leadId,
        purchasePrice,
        earnestMoney,
        closingDays,
        additionalTerms
      );
      
      const summary = formatAgreementSummary(agreementData);
      
      return {
        content: [{ type: "text", text: summary }],
        structuredContent: agreementData,
      };
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error generating agreement: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// 9. mark_agreement_sent - Track agreement status
server.registerTool(
  "mark_agreement_sent",
  {
    title: "Mark Agreement Sent",
    description: `Record that an agreement has been sent to a lead.

Updates the lead's status in the database to track agreement workflow.

Args:
  - leadId: The lead ID
  - agreementId: Unique identifier for the agreement (e.g., DocuSign envelope ID)
  - sentVia: How it was sent - 'email', 'sms', or 'docusign' (default: 'email')

Returns: Updated agreement status`,
    inputSchema: z.object({
      leadId: z.string()
        .describe("The lead ID"),
      agreementId: z.string()
        .describe("Unique identifier for the agreement"),
      sentVia: z.enum(['email', 'sms', 'docusign'])
        .optional()
        .default('email')
        .describe("How the agreement was sent"),
    }).strict(),
    annotations: {
      readOnlyHint: false,
      destructiveHint: false,
      idempotentHint: false,
      openWorldHint: false,
    },
  },
  async ({ leadId, agreementId, sentVia }) => {
    try {
      const status = await markAgreementSent(leadId, agreementId, sentVia);
      
      return {
        content: [{
          type: "text",
          text: `✅ Agreement marked as sent!
Lead ID: ${leadId}
Agreement ID: ${agreementId}
Sent Via: ${sentVia}
Sent At: ${status.sentAt}`,
        }],
        structuredContent: status,
      };
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error marking agreement sent: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// ============================================================
// TELEGRAM TOOL
// ============================================================

// 10. send_telegram_message - Send notifications directly
server.registerTool(
  "send_telegram_message",
  {
    title: "Send Telegram Message",
    description: `Send a message via Telegram bot.

Use this for notifications, alerts, and the 8 AM daily summary.
Supports HTML and Markdown formatting.

Args:
  - text: The message to send
  - chatId: Telegram chat ID (uses default if not provided)
  - parseMode: Message format - 'HTML', 'Markdown', or 'MarkdownV2'
  - silent: Send without notification sound (default: false)

Returns: Success status and message ID`,
    inputSchema: z.object({
      text: z.string()
        .min(1)
        .max(4096)
        .describe("The message to send"),
      chatId: z.string()
        .optional()
        .describe("Telegram chat ID (uses default if not provided)"),
      parseMode: z.enum(['HTML', 'Markdown', 'MarkdownV2'])
        .optional()
        .describe("Message format"),
      silent: z.boolean()
        .optional()
        .default(false)
        .describe("Send without notification sound"),
    }).strict(),
    annotations: {
      readOnlyHint: false,
      destructiveHint: false,
      idempotentHint: false,
      openWorldHint: true,
    },
  },
  async ({ text, chatId, parseMode, silent }) => {
    try {
      const targetChatId = chatId || TELEGRAM_DEFAULT_CHAT_ID;
      
      if (!targetChatId) {
        return {
          content: [{
            type: "text",
            text: "❌ Error: No chat ID provided and no default configured",
          }],
          isError: true,
        };
      }
      
      const result = await telegramClient.sendMessage(targetChatId, text, parseMode, silent);
      
      if (result.ok) {
        return {
          content: [{
            type: "text",
            text: `✅ Message sent successfully!\nMessage ID: ${result.messageId}`,
          }],
          structuredContent: result,
        };
      } else {
        return {
          content: [{
            type: "text",
            text: `❌ Failed to send message: ${result.error}`,
          }],
          isError: true,
        };
      }
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error sending Telegram message: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// ============================================================
// AGENT MEMORY TOOLS
// ============================================================

// 11. log_agent_action - Log what ALEX/ELEANOR/SAM did
server.registerTool(
  "log_agent_action",
  {
    title: "Log Agent Action",
    description: `Log an action performed by one of the MaxSam agents (ALEX, ELEANOR, or SAM).

Records agent activity in the database for tracking, debugging, and analytics.

Args:
  - agentName: Which agent performed the action - 'ALEX', 'ELEANOR', or 'SAM'
  - actionType: Type of action (e.g., 'skip_trace', 'lead_score', 'sms_sent')
  - actionDetails: JSON object with action-specific details
  - leadId: Optional lead ID this action relates to
  - success: Whether the action succeeded
  - errorMessage: Error message if action failed
  - duration: Action duration in milliseconds

Returns: Confirmation of logged action`,
    inputSchema: z.object({
      agentName: z.enum(AGENT_NAMES)
        .describe("Which agent performed the action"),
      actionType: z.string()
        .describe("Type of action performed"),
      actionDetails: z.record(z.unknown())
        .describe("Action-specific details as JSON"),
      leadId: z.string()
        .optional()
        .describe("Optional lead ID this action relates to"),
      success: z.boolean()
        .describe("Whether the action succeeded"),
      errorMessage: z.string()
        .optional()
        .describe("Error message if action failed"),
      duration: z.number()
        .optional()
        .describe("Action duration in milliseconds"),
    }).strict(),
    annotations: {
      readOnlyHint: false,
      destructiveHint: false,
      idempotentHint: false,
      openWorldHint: false,
    },
  },
  async ({ agentName, actionType, actionDetails, leadId, success, errorMessage, duration }) => {
    try {
      const action = await supabaseClient.logAgentAction({
        agentName,
        actionType,
        actionDetails,
        leadId,
        success,
        errorMessage,
        timestamp: new Date().toISOString(),
        duration,
      });
      
      const emoji = success ? '✅' : '❌';
      
      return {
        content: [{
          type: "text",
          text: `${emoji} Agent action logged!
Agent: ${agentName}
Action: ${actionType}
Success: ${success}
${leadId ? `Lead ID: ${leadId}` : ''}
${duration ? `Duration: ${duration}ms` : ''}`,
        }],
        structuredContent: action,
      };
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error logging agent action: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// 12. get_agent_logs - View agent activity
server.registerTool(
  "get_agent_logs",
  {
    title: "Get Agent Logs",
    description: `Retrieve logged actions from MaxSam agents.

Filter by agent name, action type, date range, success status, and lead ID.
Returns logs sorted by timestamp (newest first).

Args:
  - agentName: Filter by agent - 'ALEX', 'ELEANOR', or 'SAM'
  - actionType: Filter by action type
  - leadId: Filter by lead ID
  - success: Filter by success status
  - startDate: Filter by start date (ISO format)
  - endDate: Filter by end date (ISO format)
  - limit: Maximum logs to return (default: 50)

Returns: Array of agent action logs`,
    inputSchema: z.object({
      agentName: z.enum(AGENT_NAMES)
        .optional()
        .describe("Filter by agent name"),
      actionType: z.string()
        .optional()
        .describe("Filter by action type"),
      leadId: z.string()
        .optional()
        .describe("Filter by lead ID"),
      success: z.boolean()
        .optional()
        .describe("Filter by success status"),
      startDate: z.string()
        .optional()
        .describe("Filter by start date (ISO format)"),
      endDate: z.string()
        .optional()
        .describe("Filter by end date (ISO format)"),
      limit: z.number()
        .int()
        .min(1)
        .max(500)
        .optional()
        .default(50)
        .describe("Maximum logs to return"),
    }).strict(),
    annotations: {
      readOnlyHint: true,
      destructiveHint: false,
      idempotentHint: true,
      openWorldHint: false,
    },
  },
  async (params) => {
    try {
      const logs = await supabaseClient.getAgentLogs(params);
      
      if (logs.length === 0) {
        return {
          content: [{ type: "text", text: "No agent logs found matching the criteria." }],
          structuredContent: { logs: [], count: 0 },
        };
      }
      
      // Summarize logs
      const summary = logs.slice(0, 10).map(log => {
        const emoji = log.success ? '✅' : '❌';
        return `${emoji} [${log.agentName}] ${log.actionType} - ${new Date(log.timestamp).toLocaleString()}`;
      }).join('\n');
      
      const text = `📋 Agent Logs (${logs.length} found)
${params.agentName ? `Agent: ${params.agentName}` : 'All agents'}
${params.actionType ? `Action: ${params.actionType}` : ''}

Recent Activity:
${summary}
${logs.length > 10 ? `\n... and ${logs.length - 10} more` : ''}`;
      
      return {
        content: [{ type: "text", text }],
        structuredContent: { logs, count: logs.length },
      };
    } catch (error) {
      return {
        content: [{
          type: "text",
          text: `Error fetching agent logs: ${error instanceof Error ? error.message : String(error)}`,
        }],
        isError: true,
      };
    }
  }
);

// ============================================================
// SERVER STARTUP
// ============================================================

async function main(): Promise<void> {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("MaxSam N8N MCP Server v2.0.0 started");
  console.error("Tools available: 12");
  console.error("- N8N: n8n_get_credentials, n8n_test_webhook, n8n_get_execution_data, n8n_duplicate_workflow");
  console.error("- Property: calculate_offer_price, calculate_buybox_price, get_leads_missing_arv");
  console.error("- Agreement: generate_agreement_data, mark_agreement_sent");
  console.error("- Telegram: send_telegram_message");
  console.error("- Agent Memory: log_agent_action, get_agent_logs");
}

main().catch((error) => {
  console.error("Server error:", error);
  process.exit(1);
});
